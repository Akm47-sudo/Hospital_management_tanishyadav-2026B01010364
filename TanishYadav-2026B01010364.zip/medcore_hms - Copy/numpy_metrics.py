import numpy as np
from hospital_data import load_records, DATASET_PATH


def build_hospital_arrays(filepath=DATASET_PATH):
    """Builds 1D and 2D NumPy arrays from complete numeric patient records."""
    records = load_records(filepath)

    ages = []
    days_list = []
    bills = []

    for rec in records:
        if rec["age"] != "" and rec["days_admitted"] != "" and rec["total_bill"] != "":
            ages.append(float(rec["age"]))
            days_list.append(float(rec["days_admitted"]))
            bills.append(float(rec["total_bill"]))

    # 1D NumPy Arrays
    ages_1d = np.array(ages, dtype=float)
    days_1d = np.array(days_list, dtype=float)
    bills_1d = np.array(bills, dtype=float)

    # 2D NumPy Matrix (N x 3: [Age, Days Admitted, Total Bill])
    patient_matrix_2d = np.column_stack((ages_1d, days_1d, bills_1d))
    return ages_1d, days_1d, bills_1d, patient_matrix_2d


def run_numpy_analysis(filepath=DATASET_PATH):
    """Performs NumPy array operations, statistical summaries, and cost outlier detection."""
    ages_1d, days_1d, bills_1d, matrix_2d = build_hospital_arrays(filepath)

    print("\n" + "=" * 74)
    print("               NUMPY HOSPITAL FINANCIAL & STAY ANALYTICS")
    print("=" * 74)

    # 1. 1D & 2D Array Shapes
    print(f"1D Billing Array Shape      : {bills_1d.shape}")
    print(f"2D Patient Matrix Shape     : {matrix_2d.shape}  (Cols: Age, Days, Bill INR)")

    # 2. Array Indexing & Slicing
    print("\n--- Array Indexing & Slicing ---")
    print(f"First Patient Record [Age, Days, Bill] : {matrix_2d[0]}")
    print(f"Last Patient Total Bill (index -1)     : INR {bills_1d[-1]:,.2f}")
    print("First 5 Patients [Age, Days Admitted]  :")
    print(matrix_2d[:5, :2])
    print(f"Every 10th Patient Stay (slice ::10)   : {days_1d[::10]}")

    # 3. Core Aggregations: Sum, Mean, Max, Min, Standard Deviation
    bill_sum = np.sum(bills_1d)
    bill_mean = np.mean(bills_1d)
    bill_max = np.max(bills_1d)
    bill_min = np.min(bills_1d)
    bill_std = np.std(bills_1d)

    days_sum = np.sum(days_1d)
    days_mean = np.mean(days_1d)
    days_max = np.max(days_1d)
    days_min = np.min(days_1d)
    days_std = np.std(days_1d)

    print("\n--- Core NumPy Statistical Metrics ---")
    print(f"{'Metric':<26} {'Total Bill (INR)':>20} {'Stay Duration (Days)':>22}")
    print("-" * 70)
    print(f"{'Sum':<26} {bill_sum:>20,.2f} {days_sum:>22.1f}")
    print(f"{'Mean':<26} {bill_mean:>20,.2f} {days_mean:>22.2f}")
    print(f"{'Maximum':<26} {bill_max:>20,.2f} {days_max:>22.1f}")
    print(f"{'Minimum':<26} {bill_min:>20,.2f} {days_min:>22.1f}")
    print(f"{'Standard Deviation (std)':<26} {bill_std:>20,.2f} {days_std:>22.2f}")

    # 4. Meaningful Insights: Revenue per Bed-Day & High-Cost Billing Outliers (Z > 1.5)
    rev_per_bed_day = bill_sum / days_sum
    z_scores = (bills_1d - bill_mean) / bill_std
    high_cost_outliers = bills_1d[z_scores > 1.5]

    print("\n--- Actionable Hospital Insights (NumPy) ---")
    print(f"Average Revenue per Occupied Bed-Day : INR {rev_per_bed_day:,.2f}")
    print(f"High-Bill Outlier Threshold (Z>1.5)  : INR {bill_mean + 1.5 * bill_std:,.2f}")
    print(f"High-Cost Outlier Cases Detected     : {len(high_cost_outliers)}")
    if len(high_cost_outliers) > 0:
        formatted = [f"INR {val:,.2f}" for val in np.sort(high_cost_outliers)[::-1]]
        print(f"Outlier Billing Amounts              : {', '.join(formatted)}")

    return {
        "total_revenue": float(bill_sum),
        "avg_bill": float(bill_mean),
        "bill_std": float(bill_std),
        "avg_stay": float(days_mean),
        "rev_per_bed_day": float(rev_per_bed_day),
        "outlier_count": int(len(high_cost_outliers)),
    }