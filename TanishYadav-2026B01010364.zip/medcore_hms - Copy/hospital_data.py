import csv
import random

# --- PYTHON DATA STRUCTURE 1: TUPLES (Immutable Schema & Valid Categories) ---
CSV_HEADERS = (
    "patient_id",
    "name",
    "age",
    "gender",
    "department",
    "ward_type",
    "days_admitted",
    "total_bill",
    "severity_score",
    "status",
)
VALID_DEPARTMENTS = (
    "Cardiology",
    "Orthopedics",
    "Neurology",
    "Pediatrics",
    "General Medicine",
    "Emergency",
)
VALID_WARDS = ("General", "Semi-Private", "Private", "ICU")
VALID_STATUSES = ("Admitted", "Under Observation", "Critical", "Discharged")

DATASET_PATH = "hospital_records.csv"


def determine_status(severity_score, ward_type):
    """Determines initial patient status from clinical severity and ward placement."""
    if severity_score == "" or severity_score is None:
        return "Under Observation"
    score = float(severity_score)
    if score >= 8.0 or ward_type == "ICU":
        return "Critical"
    elif score >= 5.0:
        return "Admitted"
    elif score >= 3.0:
        return "Under Observation"
    return "Discharged"


def initialize_dataset(filepath=DATASET_PATH):
    """Generates a realistic 60-patient hospital CSV dataset if not already present."""
    try:
        with open(filepath, mode="r", encoding="utf-8"):
            return  # File already exists, skip generation
    except FileNotFoundError:
        pass

    random.seed(108)
    first_names = [
        "Aarav", "Ananya", "Vihaan", "Diya", "Rohan", "Priya", "Kabir", "Meera",
        "Arjun", "Sneha", "Aditya", "Kavya", "Siddharth", "Nisha", "Vikram", "Pooja",
        "Nikhil", "Riya", "Dev", "Ishita",
    ]
    last_names = [
        "Sharma", "Verma", "Singh", "Yadav", "Gupta", "Patel", "Nair", "Mehta",
        "Chauhan", "Joshi", "Kapoor", "Rao", "Malhotra", "Bansal", "Mishra",
    ]

    # Daily ward cost in INR
    ward_daily_rate = {
        "General": 2200,
        "Semi-Private": 4500,
        "Private": 8000,
        "ICU": 16500,
    }

    # --- PYTHON DATA STRUCTURE 2: LIST & LIST METHODS (.append) ---
    records = []
    for i in range(1, 61):
        dept = random.choices(
            VALID_DEPARTMENTS, weights=[20, 18, 14, 15, 20, 13], k=1
        )[0]
        ward = random.choices(VALID_WARDS, weights=[35, 25, 22, 18], k=1)[0]

        age = random.randint(1, 14) if dept == "Pediatrics" else random.randint(18, 82)
        gender = random.choice(["M", "F"])
        days = random.randint(2, 14) if ward == "ICU" else random.randint(1, 10)

        # Clinical severity (1.0 - 10.0)
        severity = round(
            random.uniform(7.2, 9.9) if ward == "ICU" else random.uniform(1.8, 7.8), 1
        )

        # Total bill = (days * daily rate) + diagnostics/procedure surcharge
        procedure_fee = (
            random.randint(3500, 45000)
            if dept in ("Cardiology", "Neurology", "Orthopedics")
            else random.randint(1500, 15000)
        )
        total_bill = round(float(days * ward_daily_rate[ward] + procedure_fee), 2)

        # Intentional missing values (5 records) to demonstrate Pandas imputation
        if i in (9, 27, 44):
            severity = ""
        if i in (16, 51):
            total_bill = ""

        # --- PYTHON DATA STRUCTURE 3: DICTIONARY ---
        record = {
            "patient_id": f"PAT-{1000 + i}",
            "name": f"{random.choice(first_names)} {random.choice(last_names)}",
            "age": age,
            "gender": gender,
            "department": dept,
            "ward_type": ward,
            "days_admitted": days,
            "total_bill": total_bill,
            "severity_score": severity,
            "status": determine_status(severity, ward),
        }
        records.append(record)

    save_records(records, filepath)


def load_records(filepath=DATASET_PATH):
    """Reads patient records from the CSV file using Python file handling."""
    initialize_dataset(filepath)
    records = []
    with open(filepath, mode="r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            records.append(row)
    return records


def save_records(records, filepath=DATASET_PATH):
    """Writes all patient record dictionaries back to the CSV file."""
    with open(filepath, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=CSV_HEADERS)
        writer.writeheader()
        writer.writerows(records)


def display_records_table(records, limit=None):
    """Renders patient records in a clean fixed-width table for the VS Code terminal."""
    if not records:
        print("\n[!] No patient records found.")
        return

    rows = records[:limit] if limit else records
    divider = "-" * 114
    print("\n" + divider)
    print(
        f"{'ID':<9} {'Patient Name':<19} {'Age':>3} {'Sex':<3} {'Department':<17} "
        f"{'Ward':<13} {'Days':>4} {'Bill (INR)':>12} {'Sev':>5} {'Status':<17}"
    )
    print(divider)

    for rec in rows:
        bill_str = f"{float(rec['total_bill']):,.2f}" if rec.get("total_bill") else "N/A"
        sev_str = str(rec.get("severity_score") or "N/A")
        # Dictionary method .get()
        print(
            f"{rec.get('patient_id', ''):<9} "
            f"{rec.get('name', '')[:18]:<19} "
            f"{str(rec.get('age', '')):>3} "
            f"{rec.get('gender', ''):<3} "
            f"{rec.get('department', '')[:16]:<17} "
            f"{rec.get('ward_type', ''):<13} "
            f"{str(rec.get('days_admitted', '')):>4} "
            f"{bill_str:>12} "
            f"{sev_str:>5} "
            f"{rec.get('status', ''):<17}"
        )
    print(divider)
    print(f"Displaying {len(rows)} of {len(records)} total patient records.")


def add_patient_record(filepath=DATASET_PATH):
    """Adds a new validated patient record to the dataset."""
    records = load_records(filepath)
    existing_ids = {rec["patient_id"].upper() for rec in records}  # Set for fast lookup

    print("\n--- ADMIT / ADD NEW PATIENT RECORD ---")
    pat_id = input("Patient ID (e.g., PAT-1061): ").strip().upper()
    if not pat_id or pat_id in existing_ids:
        print("[!] Invalid or duplicate Patient ID. Operation cancelled.")
        return

    name = input("Patient Full Name: ").strip()
    gender = input("Gender (M/F/Other): ").strip().capitalize()
    print("Departments:", ", ".join(VALID_DEPARTMENTS))
    dept = input("Department: ").strip()
    if dept not in VALID_DEPARTMENTS:
        print("[!] Invalid department selected.")
        return

    print("Ward Types:", ", ".join(VALID_WARDS))
    ward = input("Ward Type: ").strip()
    if ward not in VALID_WARDS:
        print("[!] Invalid ward type selected.")
        return

    try:
        age = int(input("Age (years): ").strip())
        days = int(input("Days Admitted: ").strip())
        total_bill = round(float(input("Total Bill (INR): ").strip()), 2)
        severity = round(float(input("Severity Score (1.0 - 10.0): ").strip()), 1)
    except ValueError:
        print("[!] Age, Days, Bill, and Severity must be numeric values.")
        return

    new_record = {
        "patient_id": pat_id,
        "name": name,
        "age": age,
        "gender": gender,
        "department": dept,
        "ward_type": ward,
        "days_admitted": days,
        "total_bill": total_bill,
        "severity_score": severity,
        "status": determine_status(severity, ward),
    }

    records.append(new_record)
    # List method .sort()
    records.sort(key=lambda r: r["patient_id"])
    save_records(records, filepath)
    print(f"[+] Patient {pat_id} ({name}) added successfully.")


def search_patient_record(filepath=DATASET_PATH):
    """Searches patients by Patient ID, Name, or Department."""
    records = load_records(filepath)
    query = input("\nEnter Patient ID, Name, or Department keyword: ").strip().lower()
    matches = [
        rec for rec in records
        if query in rec["patient_id"].lower()
        or query in rec["name"].lower()
        or query in rec["department"].lower()
    ]
    if matches:
        display_records_table(matches)
    else:
        print(f"[!] No records found matching '{query}'.")


def update_patient_record(filepath=DATASET_PATH):
    """Updates an existing patient record using Dictionary .update() method."""
    records = load_records(filepath)
    target_id = input("\nEnter Patient ID to update (e.g., PAT-1001): ").strip().upper()

    for rec in records:
        if rec["patient_id"].upper() == target_id:
            print(
                f"Found: {rec['name']} | Dept: {rec['department']} | "
                f"Ward: {rec['ward_type']} | Status: {rec['status']}"
            )
            print("(Press Enter to keep the current value)")

            new_ward = input(f"New Ward {VALID_WARDS} [{rec['ward_type']}]: ").strip()
            new_days = input(f"New Days Admitted [{rec['days_admitted']}]: ").strip()
            new_bill = input(f"New Total Bill INR [{rec['total_bill']}]: ").strip()
            new_status = input(f"New Status {VALID_STATUSES} [{rec['status']}]: ").strip()

            updates = {}
            if new_ward:
                if new_ward not in VALID_WARDS:
                    print("[!] Invalid ward type. Update cancelled.")
                    return
                updates["ward_type"] = new_ward

            if new_status:
                if new_status not in VALID_STATUSES:
                    print("[!] Invalid status. Update cancelled.")
                    return
                updates["status"] = new_status

            try:
                if new_days:
                    updates["days_admitted"] = int(new_days)
                if new_bill:
                    updates["total_bill"] = round(float(new_bill), 2)
            except ValueError:
                print("[!] Numeric fields must be valid numbers. Update cancelled.")
                return

            # Dictionary method .update()
            rec.update(updates)
            save_records(records, filepath)
            print(f"[+] Patient {target_id} updated successfully.")
            return

    print(f"[!] Patient ID '{target_id}' not found.")


def delete_patient_record(filepath=DATASET_PATH):
    """Deletes a patient record by ID using List .pop() method."""
    records = load_records(filepath)
    target_id = input("\nEnter Patient ID to delete (e.g., PAT-1060): ").strip().upper()

    for idx, rec in enumerate(records):
        if rec["patient_id"].upper() == target_id:
            removed = records.pop(idx)  # List method .pop()
            save_records(records, filepath)
            print(f"[-] Deleted record {removed['patient_id']} ({removed['name']}).")
            return

    print(f"[!] Patient ID '{target_id}' not found.")


def get_data_structure_summary(filepath=DATASET_PATH):
    """Demonstrates Set operations and Dictionary methods (.get, .items) on hospital data."""
    records = load_records(filepath)

    # --- PYTHON DATA STRUCTURE 4: SETS & SET OPERATIONS ---
    all_depts = {rec["department"] for rec in records}
    critical_depts = {rec["department"] for rec in records if rec["status"] == "Critical"}
    non_critical_depts = all_depts.difference(critical_depts)

    # Dictionary frequency count using .get()
    status_counts = {}
    for rec in records:
        st = rec.get("status", "Unknown")
        status_counts[st] = status_counts.get(st, 0) + 1
        
    return {
        "total_patients": len(records),
        "all_depts": sorted(all_depts),
        "critical_depts": sorted(critical_depts),
        "non_critical_depts": sorted(non_critical_depts),
        "status_counts": status_counts,
    }