from datetime import datetime
from hospital_data import (
    initialize_dataset,
    load_records,
    display_records_table,
    add_patient_record,
    search_patient_record,
    update_patient_record,
    delete_patient_record,
    get_data_structure_summary,
)
from numpy_metrics import run_numpy_analysis
from pandas_insights import run_pandas_analysis

REPORT_PATH = "hospital_summary_report.txt"


def generate_summary_report():
    """Combines Data Structure, NumPy, and Pandas analytics into a report & exports it."""
    ds_info = get_data_structure_summary()
    np_info = run_numpy_analysis()
    pd_info = run_pandas_analysis()

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "=" * 74,
        "              MEDCORE HMS | EXECUTIVE SUMMARY REPORT",
        f"              Generated On: {timestamp}",
        "=" * 74,
        f"Total Patient Records            : {ds_info['total_patients']}",
        f"Active Departments (Set)         : {', '.join(ds_info['all_depts'])}",
        f"Departments w/ Critical Patients : {', '.join(ds_info['critical_depts']) or 'None'}",
        f"Departments w/o Critical Cases   : {', '.join(ds_info['non_critical_depts']) or 'None'}",
        "",
        "Patient Status Distribution (Dictionary Counts):",
    ]
    # Dictionary method .items()
    for status, count in ds_info["status_counts"].items():
        lines.append(f"  - {status:<18}: {count}")

    lines.extend([
        "",
        "NumPy Financial & Stay Metrics:",
        f"  - Total Recorded Revenue       : INR {np_info['total_revenue']:,.2f}",
        f"  - Average Patient Bill         : INR {np_info['avg_bill']:,.2f}",
        f"  - Billing Standard Deviation   : INR {np_info['bill_std']:,.2f}",
        f"  - Average Hospital Stay        : {np_info['avg_stay']:.2f} days",
        f"  - Avg Revenue per Bed-Day      : INR {np_info['rev_per_bed_day']:,.2f}",
        f"  - High-Bill Outliers (Z > 1.5) : {np_info['outlier_count']}",
        "",
        "Pandas Clinical & Departmental Insights:",
        f"  - Top Revenue Department       : {pd_info['top_rev_dept']} "
        f"(INR {pd_info['top_rev_amount']:,.2f})",
        f"  - Highest Severity Department  : {pd_info['highest_sev_dept']}",
        f"  - Current ICU Occupancy        : {pd_info['icu_occupancy_pct']}%",
        f"  - Stay-to-Bill Correlation     : {pd_info['stay_bill_corr']:+.3f}",
        "=" * 74,
    ])

    report_content = "\n".join(lines)
    print("\n" + report_content)

    # Python File Handling: Write summary report to file
    with open(REPORT_PATH, mode="w", encoding="utf-8") as f:
        f.write(report_content + "\n")
    print(f"\n[+] Summary report exported to: {REPORT_PATH}")


def show_menu():
    """Displays the interactive CLI navigation menu."""
    print("\n" + "=" * 56)
    print("    MEDCORE HMS | HOSPITAL MANAGEMENT & ANALYTICS")
    print("=" * 56)
    print("  1. Display All Patient Records")
    print("  2. Add (Admit) a New Patient Record")
    print("  3. Search Patient (ID, Name, or Department)")
    print("  4. Update Existing Patient Record")
    print("  5. Delete Patient Record")
    print("  6. Run NumPy Billing & Stay Analytics")
    print("  7. Run Pandas Departmental & ICU Insights")
    print("  8. Generate & Export Full Summary Report")
    print("  0. Exit")
    print("=" * 56)


def main():
    initialize_dataset()
    while True:
        show_menu()
        choice = input("Select an option (0-8): ").strip()

        if choice == "1":
            records = load_records()
            display_records_table(records)
        elif choice == "2":
            add_patient_record()
        elif choice == "3":
            search_patient_record()
        elif choice == "4":
            update_patient_record()
        elif choice == "5":
            delete_patient_record()
        elif choice == "6":
            run_numpy_analysis()
        elif choice == "7":
            run_pandas_analysis()
        elif choice == "8":
            generate_summary_report()
        elif choice == "0":
            print("\nExiting MedCore HMS. Stay healthy!")
            break
        else:
            print("\n[!] Invalid choice. Please enter a number between 0 and 8.")

        input("\nPress Enter to continue...")


if __name__ == "__main__":
    main()