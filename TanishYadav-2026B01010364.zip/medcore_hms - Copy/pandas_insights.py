import pandas as pd
from hospital_data import DATASET_PATH, initialize_dataset


def create_ward_benchmark_df():
    """Creates a custom Pandas DataFrame storing hospital ward bed capacities and tariffs."""
    ward_info = {
        "ward_type": ["General", "Semi-Private", "Private", "ICU"],
        "total_beds": [60, 40, 25, 20],
        "daily_tariff_inr": [2200, 4500, 8000, 16500],
        "nurse_to_patient_ratio": ["1:8", "1:5", "1:3", "1:1"],
    }
    return pd.DataFrame(ward_info)


def load_and_clean_df(filepath=DATASET_PATH):
    """Reads CSV into a Pandas DataFrame and imputes missing values."""
    initialize_dataset(filepath)
    df = pd.read_csv(filepath)

    missing_before = df.isna().sum()

    # Fill missing severity with median and missing bills with mean
    median_sev = round(df["severity_score"].median(), 1)
    mean_bill = round(df["total_bill"].mean(), 2)

    df_clean = df.fillna({"severity_score": median_sev, "total_bill": mean_bill})
    return df_clean, missing_before


def run_pandas_analysis(filepath=DATASET_PATH):
    """Executes Pandas exploration, filtering, sorting, GroupBy, and statistical analysis."""
    print("\n" + "=" * 74)
    print("             PANDAS CLINICAL & DEPARTMENTAL INTELLIGENCE")
    print("=" * 74)

    # 1. Created DataFrame
    ward_df = create_ward_benchmark_df()
    print("\n--- 1. Hospital Ward Capacity & Tariff Schedule (Created DataFrame) ---")
    print(ward_df.to_string(index=False))

    # 2. Read CSV & Handle Missing Values
    df, missing_before = load_and_clean_df(filepath)
    print("\n--- 2. Missing Values Detected & Handled ---")
    missing_cols = missing_before[missing_before > 0]
    if not missing_cols.empty:
        for col, cnt in missing_cols.items():
            print(f"  - Column '{col}': {cnt} missing value(s) imputed cleanly.")
    else:
        print("  - No missing values found in dataset.")

    # 3. Display Selected Rows and Columns
    print("\n--- 3. Selected Rows (0 to 4) & Core Columns ---")
    subset = df.loc[0:4, ["patient_id", "name", "department", "ward_type", "total_bill", "status"]]
    print(subset.to_string(index=False))

    # 4. Data Filtering & Sorting (Top 8 Highest-Billing Critical / ICU Cases)
    print("\n--- 4. Filtered & Sorted: Top 8 High-Priority Critical / ICU Cases ---")
    priority_cases = (
        df[(df["status"] == "Critical") | (df["ward_type"] == "ICU")]
        .sort_values(by="total_bill", ascending=False)
        [["patient_id", "name", "department", "ward_type", "days_admitted", "total_bill", "severity_score"]]
        .head(8)
    )
    print(priority_cases.to_string(index=False))

    # 5. GroupBy: Departmental Performance
    print("\n--- 5. GroupBy Analysis: Revenue & Clinical Load by Department ---")
    dept_group = df.groupby("department").agg(
        Patients=("patient_id", "count"),
        Avg_Stay_Days=("days_admitted", "mean"),
        Avg_Severity=("severity_score", "mean"),
        Total_Revenue_INR=("total_bill", "sum"),
        Avg_Bill_INR=("total_bill", "mean"),
    ).round(2).sort_values(by="Total_Revenue_INR", ascending=False)
    print(dept_group.to_string())

    # 6. GroupBy: Ward Utilization & Average Billing
    print("\n--- 6. GroupBy Analysis: Utilization & Cost by Ward Type ---")
    ward_group = df.groupby("ward_type").agg(
        Patients=("patient_id", "count"),
        Avg_Stay_Days=("days_admitted", "mean"),
        Avg_Bill_INR=("total_bill", "mean"),
        Max_Bill_INR=("total_bill", "max"),
    ).round(2)
    print(ward_group.to_string())

    # 7. Descriptive Statistics & Correlation Analysis
    print("\n--- 7. Statistical Analysis (Numeric Summary) ---")
    num_cols = ["age", "days_admitted", "total_bill", "severity_score"]
    print(df[num_cols].describe().round(2).to_string())

    corr_matrix = df[num_cols].corr().round(3)
    stay_bill_corr = corr_matrix.loc["days_admitted", "total_bill"]
    sev_bill_corr = corr_matrix.loc["severity_score", "total_bill"]

    top_rev_dept = dept_group["Total_Revenue_INR"].idxmax()
    highest_sev_dept = dept_group["Avg_Severity"].idxmax()
    icu_count = int((df["ward_type"] == "ICU").sum())

    print("\n--- Key Data-Driven Hospital Insights ---")
    print(f"  * Top Revenue-Generating Dept    : {top_rev_dept} "
          f"(INR {dept_group.loc[top_rev_dept, 'Total_Revenue_INR']:,.2f})")
    print(f"  * Highest Avg Severity Dept      : {highest_sev_dept} "
          f"(Avg Score: {dept_group.loc[highest_sev_dept, 'Avg_Severity']}/10)")
    print(f"  * ICU Bed Occupancy Load         : {icu_count} / 20 beds ({icu_count / 20 * 100:.1f}%)")
    print(f"  * Stay Length vs Bill Correlation: {stay_bill_corr:+.3f}")
    print(f"  * Severity vs Bill Correlation   : {sev_bill_corr:+.3f}")

    return {
        "top_rev_dept": top_rev_dept,
        "top_rev_amount": float(dept_group.loc[top_rev_dept, "Total_Revenue_INR"]),
        "highest_sev_dept": highest_sev_dept,
        "icu_occupancy_pct": round(icu_count / 20 * 100, 1),
        "stay_bill_corr": float(stay_bill_corr),
    }